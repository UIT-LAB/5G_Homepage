package com.uitlab.a5gappproject

class NoticeItem (val Notice: String, val date: String)
