package com.uitlab.a5gappproject

class BoardItem (val board: String, val date: String)