package com.uitlab.a5gappproject

class DataPage(var color: Int)